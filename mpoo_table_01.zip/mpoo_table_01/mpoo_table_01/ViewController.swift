//
//  ViewController.swift
//  mpoo_table_01
//
//  Created by Germán Santos Jaimes on 24/04/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    

    var nombres:[String] = ["Pedro", "Juan", "Luis", "Chano"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        nombres.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        celda.textLabel?.text = nombres[indexPath.row]
        return celda
    }


}

