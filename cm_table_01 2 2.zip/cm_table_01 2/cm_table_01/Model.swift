//
//  Model.swift
//  cm_table_01
//
//  Created by Germán Santos Jaimes on 12/06/23.
//

import Foundation

struct Alumno{
    var nombre: String
    var apellido: String
    var nombreImagen: String 
}
