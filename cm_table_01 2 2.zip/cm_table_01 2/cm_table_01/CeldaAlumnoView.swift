//
//  CeldaAlumnoView.swift
//  cm_table_01
//
//  Created by Germán Santos Jaimes on 12/06/23.
//

import UIKit

class CeldaAlumnoView: UITableViewCell {

    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
