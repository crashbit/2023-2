//
//  ViewController.swift
//  cm_table_01
//
//  Created by Germán Santos Jaimes on 26/04/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var alumno:[Alumno] = [
        Alumno(nombre: "Pedro", apellido: "Gomez", nombreImagen: "Foto1"),
        Alumno(nombre: "Juan", apellido: "Perez", nombreImagen: "Foto2"),
        Alumno(nombre: "Luis", apellido: "Sanchez", nombreImagen: "Foto3"),
        Alumno(nombre: "Julieta", apellido: "Sanchez", nombreImagen: "Foto3")
        
    ]
    @IBOutlet weak var tabla: UITableView?
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        alumno.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        var dato = alumno[indexPath.row].nombre
    celda.textLabel?.text = dato
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var indexPropio = tabla?.indexPathForSelectedRow
        
        let second = segue.destination as! SecondViewController
        second.renglon = indexPropio!.row
    }


}

