//
//  ViewController.swift
//  mpoo_table_01
//
//  Created by Germán Santos Jaimes on 24/04/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    

    var nombres:[String] = ["Pedro", "Juan", "Luis", "Chano"]
    @IBOutlet weak var tabla : UITableView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        nombres.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        celda.textLabel?.text = nombres[indexPath.row]
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var miIndexPath = tabla?.indexPathForSelectedRow
        
        let second = segue.destination as! SecondViewController
        
        second.renglon = miIndexPath?.row ?? -1
        
    }

}

