//
//  SecondViewController.swift
//  mpoo_table_01
//
//  Created by Germán Santos Jaimes on 17/05/23.
//

import UIKit

class SecondViewController: UIViewController {
    
    var renglon: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("Valor recibido: \(renglon)")
        // Do any additional setup after loading the view.
    }
    

    

}
