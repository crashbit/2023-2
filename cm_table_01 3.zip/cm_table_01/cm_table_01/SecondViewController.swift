//
//  SecondViewController.swift
//  cm_table_01
//
//  Created by Germán Santos Jaimes on 17/05/23.
//

import UIKit

class SecondViewController: UIViewController {

    var renglon:Int = 0
    var nombre:String = ""
    @IBOutlet weak var letrero: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(renglon)
        letrero.text = nombre
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
