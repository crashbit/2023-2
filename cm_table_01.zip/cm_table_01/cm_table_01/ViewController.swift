//
//  ViewController.swift
//  cm_table_01
//
//  Created by Germán Santos Jaimes on 26/04/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var alumnos:[String] = ["Romel", "Laura", "Yolanda", "Jose"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        var dato = alumnos[indexPath.row]
    celda.textLabel?.text = dato
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }


}

